<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\MateriaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\DatabaseTestController;

Route::get('/test-db-connection', [DatabaseTestController::class, 'testConnection']);




Route::resource('usuarios', UsuarioController::class);

// Ruta Materias

Route::resource('materias', MateriaController::class);



/*Route::resources([
    'usuarios' => UsuarioController::class, // Ruta Usuarios
    'materias' => MateriaController::class, // Ruta Materias
]);*/