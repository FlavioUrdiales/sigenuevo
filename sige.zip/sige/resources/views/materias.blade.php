@extends('layouts.app')

<!-- AGREGAR EL JS QUE ESTA EN JS/APP.JS -->
<script src="{{ asset('../resources/js/materias.js') }}" defer></script>

@section('content')
    <div class="container-fluid">
        <div class="row">
            <h3 class="mb-5 text-center"
                style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43)); color: white; font-weight: bold;"
                class="text-center"> Catálogo Principal de Materias </h3>
            <div class="col-md-2">
                <!-- Panel Lateral o Menú -->
                <div class="card mb-3">
                    <div class="card-header"
                         style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43)); color: white; font-weight: bold;">
                        Menú de Materias
                    </div>
                    <center>
                        <ul class="list-group list-group-flush nav nav-tabs" id="myTab" role="tablist">
                            <li class="list-group-item">
                                <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                        data-bs-target="#home-tab-pane" type="button" role="tab"
                                        aria-controls="home-tab-pane" aria-selected="true" style="color:#000">CATÁLOGO
                                </button>
                            </li>
                            <li class="list-group-item">
                                <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                                        data-bs-target="#profile-tab-pane" type="button" role="tab"
                                        aria-controls="profile-tab-pane" aria-selected="false" style="color:#000">
                                    AGREGAR
                                </button>
                            </li>
                        </ul>
                    </center>

                </div>

            </div>
            <div class="tab-content col-md-10 " id="myTabContent">

                <div class="col-md-12 tab-pane fade show active" id="home-tab-pane" role="tabpanel"
                     aria-labelledby="home-tab" tabindex="0">
                    <!-- Tabla de Materias -->
                    <div class="table-responsive mb-5" style="overflow-x: auto; width: 100%; height: 80vh;">
                        <table id="materias-table" class="table table-striped table-bordered">
                            <thead class="thead-dark"
                                   style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43)); color: white; font-weight: bold;">
                            <tr>
                                <th class="filter-column">Clave</th>
                                <th class="filter-column">Nombre</th>
                                <th class="filter-column">Periodo</th>
                                <th class="filter-column">Status</th>
                                <th>Acciones</th>
                            </tr>
                            </thead>

                            <tbody>
                            @foreach ($materias as $materia)
                                <tr>
                                    <td>{{ $materia->chrClave }}</td>
                                    <td>{{ $materia->chrNombre }}</td>
                                    <td>{{ $materia->chrClavePeriodo }}</td>
                                    <td>{{ $materia->chrStatus }}</td>
                                    <td>
                                        <button class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#modalEditarMateria"
                                                onclick="editarMateria({{ $materia->id }})"><i
                                                    class="fas fa-pen-alt"></i></button>
                                        <button class="btn btn-danger" data-bs-toggle="modal"
                                                data-bs-target="#modalEliminarMateria"
                                                onclick="eliminarMateria({{ $materia->id }})"><i
                                                    class="fas fa-trash-alt"></i></button>
                                    </td>

                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-12 tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab"
                     tabindex="0">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header"
                                 style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43)); color: white; font-weight: bold;">
                                Crear Materia
                            </div>
                            <!-- Agregar materia -->
                            <div class="card-body">
                                <form id="agregarMateria" action="{{ route('materias.store') }}" method="POST"
                                      style="overflow-x: auto; width: 100%; height: 80vh;">
                                    @csrf
                                    <div class="row">
                                        <!-- Clave -->
                                        <div class="form-group col-md-6">
                                            <label for="chrClave">* Clave:</label>
                                            <input type="text" name="chrClave" class="form-control" id="chrClave"
                                                   required>
                                        </div>
                                        <!-- Nombre -->
                                        <div class="form-group col-md-6">
                                            <label for="chrNombre">* Nombre:</label>
                                            <input type="text" name="chrNombre" class="form-control" id="chrNombre"
                                                   required>
                                        </div>
                                        <!-- Escuela -->
                                        <div class="form-group col-md-12">
                                            <label for="chrClaveEscuela">* Pertenece a:</label>
                                            <select name="chrClaveEscuela" class="form-control" id="chrClaveEscuela"
                                                    required>
                                                <option value="">Selecciona una opción</option>
                                                <option value="0001">Andrade</option>
                                                <option value="0002">Juan Alonso de Torres</option>
                                                <option value="0003">San Francisco del Rincón</option>
                                                <option value="0004">Silao</option>
                                            </select>
                                        </div>
                                        <!-- Curso -->
                                        <div class="form-group col-md-12">
                                            <label for="chrClaveCurso">* Del curso:</label>
                                            <select name="chrClaveCurso" class="form-control" id="chrClaveCurso"
                                                    required>
                                                <option value="">Selecciona una opción</option>
                                                <option value="000000CR">Criminología</option>
                                            </select>
                                        </div>
                                        <!-- Periodo -->
                                        <div class="form-group col-md-12">
                                            <label for="chrClavePeriodo">* En el:</label>
                                            <select name="chrClavePeriodo" class="form-control" id="chrClavePeriodo"
                                                    required>
                                                <option value="">Selecciona una opción</option>
                                                <option value="001">1° Cuatrimestre</option>
                                                <option value="002">2° Cuatrimestre</option>
                                                <option value="003">3° Cuatrimestre</option>
                                                <option value="004">4° Cuatrimestre</option>
                                                <option value="005">5° Cuatrimestre</option>
                                                <option value="006">6° Cuatrimestre</option>
                                                <option value="007">7° Cuatrimestre</option>
                                                <option value="008">8° Cuatrimestre</option>
                                                <option value="009">9° Cuatrimestre</option>
                                                <option value="010">10° Cuatrimestre</option>
                                                <option value="011">11° Cuatrimestre</option>
                                                <option value="012">12° Cuatrimestre</option>
                                                <option value="013">13° Cuatrimestre</option>
                                                <option value="014">14° Cuatrimestre</option>
                                                <option value="015">15° Cuatrimestre</option>
                                                <option value="016">16° Cuatrimestre</option>
                                                <option value="017">17° Cuatrimestre</option>
                                                <option value="018">18° Cuatrimestre</option>
                                                <option value="S01">1° Semestre</option>
                                                <option value="S02">2° Semestre</option>
                                                <option value="S03">3° Semestre</option>
                                                <option value="S04">4° Semestre</option>
                                                <option value="S05">5° Semestre</option>
                                                <option value="S06">6° Semestre</option>
                                                <option value="S07">7° Semestre</option>
                                                <option value="S08">8° Semestre</option>
                                                <option value="S09">9° Semestre</option>
                                                <option value="S10">10° Semestre</option>
                                            </select>
                                        </div>
                                        <!-- Créditos -->
                                        <div class="form-group col-md-4">
                                            <label for="intCreditos">* Créditos:</label>
                                            <input type="number" name="intCreditos" class="form-control"
                                                   id="intCreditos" required min="0" max="11.25">
                                            <!-- Materia Previa 1 -->
                                            <div class="form-group col-md-12">
                                                <label for="chrClaveMateriaAntecesora1">Materia previa 1:</label>
                                                <select name="chrClaveMateriaAntecesora1" class="form-control"
                                                        id="chrClaveMateriaAntecesora1">
                                                    <option value="" selected>N/A</option>
                                                </select>
                                            </div>
                                            <!-- Materia Previa 2 -->
                                            <div class="form-group col-md-12">
                                                <label for="chrClaveMateriaAntecesora2">Materia previa 2:</label>
                                                <select name="chrClaveMateriaAntecesora2" class="form-control"
                                                        id="chrClaveMateriaAntecesora2">
                                                    <option value="" selected>N/A</option>
                                                </select>
                                            </div>
                                            <!-- Materia Previa 3 -->
                                            <div class="form-group col-md-12">
                                                <label for="chrClaveMateriaAntecesora3">Materia previa 3:</label>
                                                <select name="chrClaveMateriaAntecesora3" class="form-control"
                                                        id="chrClaveMateriaAntecesora3">
                                                    <option value="" selected>N/A</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="chrStatus">* Status:</label>
                                                <select name="chrStatus" class="form-control" required id="chrStatus">
                                                    <option value="activo" selected>Activo</option>
                                                    <option value="cancelado">Cancelado</option>
                                                </select>
                                            </div>
                                            <button id="btnCrearMateria"
                                                    class="btn btn-primary mt-3 col-md-6 offset-md-3"
                                                    style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43));">
                                                Crear Materia
                                            </button>

                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal editar-->
    <div class="modal" tabindex="-1" role="dialog" id="modalEditarMateria">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Modal body text goes here.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!--Termina la modal de editar materia  -->


    <!-- JavaScript para inicializar DataTables y dar estilo -->
    <script>
        $(document).ready(function () {
            $('#materias-table').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"
                },
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print', 'pageLength'
                ],
                "lengthMenu": [
                    [15, 25, 50, -1],
                    [15, 25, 50, "Todos"]
                ],
                "order": [
                    [0, "asc"]
                ],
                "pageLength": 15,
                "pagingType": "full_numbers",


            });

        });
    </script>

    @if (session('success'))
        <script>
            Swal.fire(
                '¡Materia creada!',
                'La materia se ha creado correctamente.',
                'success'
            )
        </script>
    @endif

@endsection