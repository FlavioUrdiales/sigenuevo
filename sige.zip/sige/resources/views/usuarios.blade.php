@extends('layouts.app')


<!-- AGREGAR EL JS QUE ESTA EN JS/APP.JS -->
    <script src="{{ asset('../resources/js/usuarios.js') }}" defer></script>

@section('content')
    <div class="container-fluid">
        <div class="row">
            <h3 class="mb-5 text-center" style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43)); color: white; font-weight: bold;" class="text-center"> Catálogo Principal de Usuarios </h3>
            <div class="col-md-2">
                <!-- Panel Lateral o Menú -->
                <div class="card mb-3">
                    <div class="card-header" style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43)); color: white; font-weight: bold;">
                        Menú de Usuarios
                    </div>
                    <center>
                    <ul class="list-group list-group-flush nav nav-tabs" id="myTab" role="tablist">
                        <li class="list-group-item"> <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true" style="color:#000">CATÁLOGO</button></li>
                        <li class="list-group-item"> <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false" style="color:#000">AGREGAR</button></li>
                    </ul>
                    </center>

                </div>

            </div>
            <div class="tab-content col-md-10 " id="myTabContent">

                <div class="col-md-12 tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                    <!-- Tabla de Usuarios -->
                    <div class="table-responsive mb-5" style="overflow-x: auto; width: 100%; height: 80vh;">
                        <table id="usuarios-table" class="table table-striped table-bordered">
                            <thead class="thead-dark" style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43)); color: white; font-weight: bold;">
                            <tr>
                                <th class="filter-column">Clave</th>
                                <th class="filter-column">Nombre</th>
                                <th class="filter-column">Escuela</th>
                                <th class="filter-column">Status</th>
                                <th>Acciones</th>
                            </tr>
                            </thead>

                            <tbody>
                            @foreach ($usuarios as $usuario)
                                <tr>
                                    <td>{{ $usuario->chrClave }}</td>
                                    <td>{{ $usuario->chrNombre }} {{ $usuario->chrPaterno }} {{ $usuario->chrMaterno }}</td>
                                    <td>{{ $usuario->Escuela }}</td>
                                    <td>{{ $usuario->chrStatus }}</td>
                                    <td> <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalEditarUsuario"  onclick="editarUsuario({{ $usuario->id }})"><i class="fas fa-pen-alt"></i></button>
                                   <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminarUsuario" onclick="eliminarUsuario({{ $usuario->id }})"><i class="fas fa-trash-alt"></i></button></td>

                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-12 tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header" style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43)); color: white; font-weight: bold;">
                                Crear Usuario
                            </div>
                            <div class="card-body">
                                <form id="agregarUsuario" action="{{ route('usuarios.store') }}" method="POST" style="overflow-x: auto; width: 100%; height: 80vh;">
                                    @csrf
                                    <div class="row">
                                        <div class="form-group col-md-6">
                                            <label for="chrClave">* Clave:</label>
                                            <input type="text" name="chrClave" class="form-control" id="chrClave" required>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="chrPassword">* Contraseña:</label>
                                            <input type="password" name="chrPassword" class="form-control" id="chrPassword" required>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="chrClavePlantel">* Pertenece a:</label>
                                            <select name="chrClavePlantel" class="form-control" id="chrClavePlantel" required>
                                                <option value="">Selecciona una opción</option>
                                                <option value="1">Andrade</option>
                                            </select>

                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="chrNombre">* Nombres:</label>
                                            <input type="text" name="chrNombre" class="form-control" id="chrNombre" required>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="chrPaterno">* Paterno:</label>
                                            <input type="text" name="chrPaterno" class="form-control" id="chrPaterno" required>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label for="chrMaterno">* Materno:</label>
                                            <input type="text" name="chrMaterno" class="form-control" id="chrMaterno" required>
                                        </div>

                                        <div class="form-group col-md-12">
                                            <label for="dtFechaNacimiento">Fecha de nacimiento:</label>
                                            <input type="date" name="dtFechaNacimiento" class="form-control" id="dtFechaNacimiento">
                                        </div>

                                        <div class="form-group col-md-12">
                                            <label for="chrCurp">* Curp:</label>
                                            <input type="text" name="chrCurp" class="form-control" id="chrCurp" required>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="chrEmail">Email:</label>
                                            <input type="text" name="chrEmail" class="form-control" id="chrEmail" >
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="chrTelefono">Telefono:</label>
                                            <input type="number" name="chrTelefono" class="form-control" id="chrTelefono" >
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="chrDomicilio">Domicilio:</label>
                                            <input type="text" name="chrDomicilio" class="form-control" id="chrDomicilio" >
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="chrRFC">RFC:</label>
                                            <input type="text" name="chrRFC" class="form-control" id="chrRFC" >
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="chrStatus">Status:</label>
                                            <select name="chrStatus" class="form-control" required id="chrStatus">
                                                <option value="activo" selected>Activo</option>
                                                <option value="cancelado">Cancelado</option>
                                            </select>
                                        </div>
                                        <button id="btnCrearUsuario" class="btn btn-primary mt-3 col-md-6 offset-md-3" style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43));">Crear Usuario</button>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
            <!-- Modal editar-->
    <div class="modal" tabindex="-1" id="modalEditarUsuario">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h1>Editar Usuario</h1>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <form class="form" id="editarUsuario" action="{{ route('$usuarioedit.update', $usuarios->id) }}">
                        <div class="col-md-6">
                            <label for="chrClave_u">* Clave:</label>
                            <input type="text" name="chrClave_u" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="chrPassword_u">* Contraseña:</label>
                            <input type="password" name="chrPassword_u" class="form-control" required>
                        </div>
                        <div class="col-md-12">
                            <label for="chrClavePlantel_u">* Pertenece a:</label>
                            <select name="chrClavePlantel_u" class="form-control" required>
                                <option value="">Selecciona una opción</option>
                                <option value="1">Andrade</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="chrNombre_u">* Nombres:</label>
                            <input type="text" name="chrNombre_u" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label for="chrPaterno_u">* Paterno:</label>
                            <input type="text" name="chrPaterno_u" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label for="chrMaterno_u">* Materno:</label>
                            <input type="text" name="chrMaterno_u" class="form-control" required>
                        </div>
                        <div class="col-md-12">
                            <label for="dtFechaNacimiento_u">Fecha de nacimiento:</label>
                            <input type="date" name="dtFechaNacimiento_u" class="form-control">
                        </div>
                        <div class="col-md-12">
                            <label for="chrCurp_u">* Curp:</label>
                            <input type="text" name="chrCurp_u" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="chrEmail_u">Email:</label>
                            <input type="text" name="chrEmail_u" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="chrTelefono_u">Telefono:</label>
                            <input type="number" name="chrTelefono_u" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="chrDomicilio_u">Domicilio:</label>
                            <input type="text" name="chrDomicilio_u" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="chrRFC_u">RFC:</label>
                            <input type="text" name="chrRFC_u" class="form-control">
                        </div>
                        <div class="col-md-12">
                            <label for="chrStatus_u">Status:</label>
                            <select name="chrStatus_u" class="form-control" required>
                                <option value="activo" selected>Activo</option>
                                <option value="cancelado">Cancelado</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button id="btnEditarUsuario" class="btn btn-primary">Editar Usuario</button>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!--Termina la modal de editar usuario  -->

        <!-- JavaScript para inicializar DataTables y dar estilo -->
        <script>
            $(document).ready(function() {
                $('#usuarios-table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"
                    },
                    dom: 'Bfrtip',
                    buttons: [
                        'copy', 'csv', 'excel', 'pdf', 'print', 'pageLength'
                    ],
                    "lengthMenu": [
                        [15, 25, 50, -1],
                        [15, 25, 50, "Todos"]
                    ],
                    "order": [
                        [0, "asc"]
                    ],
                    "pageLength": 15,
                    "pagingType": "full_numbers",


                });

            });
        </script>
        <style>
            /* Estilos para la paginación circular */
            /* Estilos para la paginación circular */
            .paginate_button {

                margin: 0 5px !important;
                border: 1px solid rgb(33, 1, 43) !important;
                padding: 5px 10px !important;
                color: #666 !important;
                font-family: "Arial", Gadget, sans-serif !important;
                background: transparent !important;
                transition: all 0.3s ease !important;
                margin-top: 10px !important;

            }
            .dataTables_filter {
                margin-top: 10px !important;
                margin-bottom: 10px !important;
                /*agarrar el input dentro de esta clase y darle estilos*/


            }

            .dataTables_filter input {
                padding: 5px 10px !important;
                transition: all 0.3s ease !important;
                margin-top: 10px !important;
                margin-bottom: 10px !important;
                margin-left: 10px !important;
                margin-right: 10px !important;
                width: 300px !important;
                height: 40px !important;
                font-size: 15px !important;
                font-weight: bold !important;
                color: rgb(33, 1, 43) !important;
                background: transparent !important;
                font-family: "Arial", Gadget, sans-serif !important;
                border: none !important;
                border-bottom: 1px solid rgb(33, 1, 43) !important;
            }
            .dataTables_filter input:focus {
                outline: none !important;
                border-bottom: 1px solid rgb(33, 1, 43) !important;
            }
            .dataTables_filter label {
                font-weight: bold !important;
                font-size: 15px !important;
                font-family: "Arial", Gadget, sans-serif !important;
                /*HACER MAYUSCULA*/
                text-transform: uppercase !important;
            }
            .dt-button {
                background: transparent !important;
                margin: 0 5px !important;
                border: 1px solid rgb(33, 1, 43) !important;
                padding: 5px 10px !important;
                color: #666 !important;
                font-family: "Arial", Gadget, sans-serif !important;
                transition: all 0.3s ease !important;
                margin-top: 10px !important;
                margin-bottom: 10px !important;
                font-weight: bold !important;
                color: rgb(33, 1, 43) !important;
            }

        </style>

        @if (session('success'))
            <script>
                Swal.fire(
                    '¡Usuario creado!',
                    'El usuario se ha creado correctamente.',
                    'success'
                )
            </script>
    @endif

@endsection