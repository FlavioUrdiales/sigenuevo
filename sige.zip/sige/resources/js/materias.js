// materias.js

// Espera a que se cargue el documento
document.addEventListener('DOMContentLoaded', function () {
    // Obtén una referencia al botón de crear materia
    var btnCrearMateria = document.getElementById('btnCrearMateria');
    var formulario = document.getElementById("agregarMateria");

    formulario.reset();
    // Agrega un evento de clic al botón
    btnCrearMateria.addEventListener('click', function (e) {
        // Evita el comportamiento predeterminado del botón (enviar el formulario)
        e.preventDefault();

        // Obtén una referencia al formulario
        var formulario = document.querySelector('form');

        // Obtén los datos del formulario
        var formData = new FormData(formulario);

        console.log(formData);

        // Realiza una solicitud AJAX para enviar los datos al servidor
        fetch(formulario.action, {
            method: 'POST',
            body: formData,

        })
            .then(response => response.json())
            .then(data => {
                // Maneja la respuesta del servidor aquí (por ejemplo, muestra un mensaje de éxito)
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Materia creada',
                        text: data.message,
                    })
                    formulario.reset();
                    window.location.reload();
                } else {
                    // Maneja los errores si es necesario
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: data.message,
                    })
                }
            })
            .catch(error => {
                console.error('Error de red:', error);

                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Error de red',
                })


            });
    });
});


//modal editar materia




