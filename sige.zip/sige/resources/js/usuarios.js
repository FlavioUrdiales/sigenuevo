// usuarios.js

// Espera a que se cargue el documento
document.addEventListener('DOMContentLoaded', function () {
    // Obtén una referencia al botón de crear usuario
    var btnCrearUsuario = document.getElementById('btnCrearUsuario');
    var formulario = document.getElementById("agregarUsuario");

    formulario.reset();
    // Agrega un evento de clic al botón
    btnCrearUsuario.addEventListener('click', function (e) {
        // Evita el comportamiento predeterminado del botón (enviar el formulario)
        e.preventDefault();

        // Obtén una referencia al formulario
        var formulario = document.querySelector('form');

        // Obtén los datos del formulario
        var formData = new FormData(formulario);

        // Realiza una solicitud AJAX para enviar los datos al servidor
        fetch(formulario.action, {
            method: 'POST',
            body: formData,
       
        })
            .then(response => response.json())
            .then(data => {
                // Maneja la respuesta del servidor aquí (por ejemplo, muestra un mensaje de éxito)
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Usuario creado',
                        text: data.message,
                    })
                    formulario.reset();
                    window.location.reload();
                } else {
                    // Maneja los errores si es necesario
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: data.message,
                    })                }
            })
            .catch(error => {
                console.error('Error de red:', error);

                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Error de red',
                })


            });
    });
});

//Editar usuario
// Espera a que se cargue el documento

document.addEventListener('DOMContentLoaded', function () {

    // Obtén una referencia al botón de editar usuario
    var btnEditarUsuario = document.getElementById('btnEditarUsuario');
    var formulario = document.getElementById("editarUsuario");

    formulario.reset();
    // Agrega un evento de clic al botón
    btnEditarUsuario.addEventListener('click', function (e) {
        // Evita el comportamiento predeterminado del botón (enviar el formulario)
        e.preventDefault();

        // Obtén una referencia al formulario
        var formulario = document.querySelector('form');

        // Obtén los datos del formulario
        var formData = new FormData(formulario);

        console.log(formData);
        alert(formData);


        // Realiza una solicitud AJAX para enviar los datos al servidor
        fetch(formulario.action, {
            method: 'POST',
            body: formData,

        })
            .then(response => response.json())
            .then(data => {
                // Maneja la respuesta del servidor aquí (por ejemplo, muestra un mensaje de éxito)
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Usuario editado',
                        text: data.message,
                    })
                    formulario.reset();
                    window.location.reload();
                } else {
                    // Maneja los errores si es necesario
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: data.message,
                    })                }
            })
            .catch(error => {
                console.error('Error de red:', error);

                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Error de red',
                })

             }







