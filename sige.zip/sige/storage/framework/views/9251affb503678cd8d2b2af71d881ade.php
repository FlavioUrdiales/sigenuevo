<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIGE</title>

    <!-- Agrega enlaces a Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Importar datatable -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">

    <!-- Importar datatable -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

    <!-- Importar datatable -->

    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

    <!-- Agreagr para los botones de exportar -->

    <script src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>

    <script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.flash.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

    <script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>

    <script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>

    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css">

    <!-- Agregar css que esta en css/app.css -->
    <link rel="stylesheet" href="<?php echo e(asset('https://pruebas.unimundial.edu.mx/sige/resources/css/app.css')); ?>">

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- AGregar font awesome -->
    <script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>


</head>

<body>
<header>
    <!-- Navbar Bootstrap -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-image: linear-gradient(to right, rgb(33, 1, 43), rgb(60, 7, 77), rgb(33, 1, 43));">
        <div class="container">
            <a class="navbar-brand" href="#" style="color:aliceblue">Sige</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" style="color:aliceblue" href="/">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:aliceblue" href="/usuarios">Usuarios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:aliceblue" href="#">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<main>
    <div class="container-fluid mt-4">
        <?php echo $__env->yieldContent('content'); ?> <!-- Esta sección se reemplazará con el contenido de las vistas -->
    </div>
</main>

<footer id="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-2 col-md-6 footer-info">
                    <img src="https://simposium.unimundial.edu.mx/assets/img/logobc.png"  alt="HUMANI">
                </div>

           

                <div class="col-lg-3 col-md-6 footer-links">
                    <h4>UNIVERSIDAD HUMANI MUNDIAL</h4>
                    <ul>
                        <li><i class="fa fa-angle-right"></i> <a href="https://unimundial.edu.mx/">Inicio</a></li>
                        <li><i class="fa fa-angle-right"></i> <a href="https://unimundial.edu.mx/requisitos-para-entrar-a-la-universidad/">Admisiones</a></li>
                        <li><i class="fa fa-angle-right"></i> <a href="#">Licenciaturas</a></li>
                        <li><i class="fa fa-angle-right"></i> <a href="#">Maestrías</a></li>
                        <li><i class="fa fa-angle-right"></i> <a href="#">Doctorado</a></li>
                        <li><i class="fa fa-angle-right"></i> <a href="https://unimundial.edu.mx/contacto/">Contacto</a></li>
                    </ul>
                </div>

                <div class="col-lg-4 col-md-6 footer-contact">
                    <h4>Contactos</h4>
                    <p>
                        <strong>Juan Alonso de Torres </strong><br>
                        <strong>Teléfonos: </strong> (477) 258 7096 - (477) 758 2152<br>
                        <strong>ANDRADE </strong><br>
                        <strong>Teléfonos: </strong> (477) 713 5005 - (477) 713 3524<br>
                        <strong>SILAO </strong><br>
                        <strong>Teléfono: </strong> (472) 748 4284 <br>
                        <strong>SAN FRANCISCO DEL RINCÓN </strong><br>
                        <strong>Teléfono: </strong> (476) 743 9442  <br>
                    </p>

                    <div class="social-links">
                        <a href="https://www.facebook.com/UniMundial" class="facebook"><i class="fa fa-facebook"></i></a>
                        <a href="https://www.instagram.com/humanimundial/" class="instagram"><i class="fa fa-instagram"></i></a>
                    </div>

                </div>

            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            © <?php echo e(date('Y')); ?>

            <strong>Universidad Humani Mundial</strong>
        </div>
        <div class="credits">

        </div>
    </div>
</footer><!-- #footer -->

<!-- Agrega enlaces a Bootstrap JavaScript (si se requieren componentes interactivos de Bootstrap) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH /home/wwunim/pruebas.unimundial.edu.mx/sige/resources/views/layouts/app.blade.php ENDPATH**/ ?>