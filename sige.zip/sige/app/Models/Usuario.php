<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Usuario extends Authenticatable
{





    use HasFactory, Notifiable;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'tblusuario';

    /**
     * The primary key associated with the table.
     *
    //  * @var string
     */
    //protected $primaryKey = 'chrClave'; // Establece la clave primaria adecuada

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'chrClave',

        'chrTipoUsuario',
        'chrModalidad',
        'chrClaveEscuela',
        'chrNombre',
        'chrPaterno',
        'chrMaterno',
        'dtFechaNacimiento',
        'chrCurp',
        'chrDomicilio',
        'chrTelefono',
        'chrEmail',
        'chrHayActa',
        'chrFotoActa',
        'chrHayDomi',
        'chrEnAccidente',
        'chrRFC',
        'chrEscuelaProcedencia',
        'chrHayCertificado',
        'chrFotoCertPrep',
        'chrGenero',
        'chrPracticasProf',
        'chrServicioCom',
        'chrTerapia',
        'chrServicioSoc',
        'chrFotoServSoc',
        'chrHayCertLic',
        'chrFotoCertLic',
        'dtfIniServSoc',
        'dtfFinServSoc',
        'chrFolioServSoc',
        'chrFechaImpCertLic',
        'chrFolioCertLic',
        'chrNotas',
        'chrPassword',
        'intConsecutivoPago',
        'chrHayAdeudoBiblio',
        'chrHayAdeudoCom',
        'chrFoto',
        'cveCiclo',
        'chrStatus',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'chrPassword',
    ];

    //quitar los timestamps

    public $timestamps = false;

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'chrEnAccidente' => 'boolean',
        // Añade más conversiones de tipos de datos según sea necesario
    ];







}
