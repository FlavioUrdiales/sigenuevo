<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Materia extends Authenticatable
{
    
    use HasFactory, Notifiable;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'tblmateria';

    /**
     * The primary key associated with the table.
     *
     * //  * @var string
     */
    //protected $primaryKey = 'chrClave'; // Establece la clave primaria adecuada

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'chrClave',
        'chrClaveCurso',
        'chrClaveEscuela',
        'chrClavePeriodo',
        'chrNombre',
        'intCreditos',
        'chrClaveMateriaAntecesora1',
        'chrClaveMateriaAntecesora2',
        'chrClaveMateriaAntecesora3',
        'chrStatus',
    ];

    //quitar los timestamps

    public $timestamps = false;

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        // Añade más conversiones de tipos de datos según sea necesario
    ];


}
