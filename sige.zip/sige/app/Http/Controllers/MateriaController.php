<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Materia; // Importa el modelo Materia correctamente

class MateriaController extends Controller
{
    public function index()
    {

        $materias = Materia::select('tblmateria')->get();


        return view('materias', compact('materias'));
    }

    public function store(Request $request)
    {
        try {
            $this->table = 'tblmateria';

            // Valida los datos del formulario
            $request->validate([
                'chrClave' => 'required|string|max:6|min:6',
                'chrClaveCurso' => 'required|string|max:8|min:8',
                'chrClaveEscuela' => 'required|string|max:4|min:4',
                'chrClavePeriodo' => 'required|string|max:3|min:3',
                'chrNombre' => 'required|string|max:255',
                'intCreditos' => 'required|decimal:0,2|numeric|min:0|max:11.25'
            ]);

            $materia = new Materia([
                'chrClave' => $request->input('chrClave'),
                'chrClaveCurso' => $request->input('chrClaveCurso'),
                'chrClaveEscuela' => $request->input('chrClaveEscuela'),
                'chrClavePeriodo' => $request->input('chrClavePeriodo'),
                'chrNombre' => $request->input('chrNombre'),
                'intCreditos' => $request->input('intCreditos'),
                'chrClaveMateriaAntecesora1' => $request->input('chrClaveMateriaAntecesora1'),
                'chrClaveMateriaAntecesora2' => $request->input('chrClaveMateriaAntecesora2'),
                'chrClaveMateriaAntecesora3' => $request->input('chrClaveMateriaAntecesora3'),
                'chrStatus' => $request->input('chrStatus'),

            ]);

            $materia->save();


            return response()->json([ 'success' => true, 'message' => 'Materia creada correctamente' ]);


        } catch (\Exception $e) {
            return response()->json([ 'success' => false, 'message' => $e->getMessage() ]);
        }
    }


    //Editar materia

    public function edit($id)
    {
        //recuperar los datos del materia

        $materia = Materia::find($id);
        return response()->json($materia);


    }

}
