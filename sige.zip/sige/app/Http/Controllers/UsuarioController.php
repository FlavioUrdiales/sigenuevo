<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Usuario; // Importa el modelo Usuario correctamente

class UsuarioController extends Controller
{
    public function index()
    {

        $usuarios = Usuario::select('tblusuario.*','tblescuela.chrNombre as Escuela')
        ->join('tblescuela','tblusuario.chrClaveEscuela','=','tblescuela.chrClave')
        ->where('chrTipoUsuario', 'usuario')->get();


        return view('usuarios', compact('usuarios'));
    }

    public function store(Request $request)
    {
        try {
            $this->table = 'tblusuario';
            
        // Valida los datos del formulario
        $request->validate([
            'chrClave' => 'required|string|max:8|unique:tblusuario',
            'chrPassword' => 'required|string|min:6',
            'chrClavePlantel' => 'required',
            'chrNombre' => 'required|string|max:255',
            'chrPaterno' => 'required|string|max:255',
            'chrMaterno' => 'required|string|max:255',
            'dtFechaNacimiento' => 'nullable|date',
            'chrCurp' => 'required|string|max:18|unique:tblusuario|min:16',
            'chrEmail' => 'nullable|email',
            'chrTelefono' => 'nullable|string|max:255',
            'chrDomicilio' => 'nullable|string|max:255',
            'chrRFC' => 'nullable|string|max:13',

        ]);

        $usuario = new Usuario([
            'chrClave' => $request->input('chrClave'),
            'chrPassword' => sha1($request->input('chrPassword')."--_*Unimu01*_"),
            'chrClaveEscuela' => $request->input('chrClavePlantel'),
            'chrNombre' => $request->input('chrNombre'),
            'chrPaterno' => $request->input('chrPaterno'),
            'chrMaterno' => $request->input('chrMaterno'),
            //si es null poner ''
            'dtFechaNacimiento' => $request->input('dtFechaNacimiento') == null ? '2023-01-01' : $request->input('dtFechaNacimiento'),
            'chrCurp' => $request->input('chrCurp') == null ? '' : $request->input('chrCurp'),
            'chrEmail' => $request->input('chrEmail') == null ? '' : $request->input('chrEmail'),
            'chrTelefono' => $request->input('chrTelefono') == null ? '' : $request->input('chrTelefono'),
            'chrDomicilio' => $request->input('chrDomicilio') == null ? '' : $request->input('chrDomicilio'),
            'chrRFC' => $request->input('chrRFC') == null ? '' : $request->input('chrRFC'),
            'chrTipoUsuario' => 'usuario',
            'chrModalidad' => '',
            'chrHayActa' => '',
            'chrFotoActa' => '',
            'chrHayDomi' => '',
            'chrEnAccidente' => '',
            'chrEscuelaProcedencia' => '',
            'chrHayCertificado' => '',
            'chrFotoCertPrep' => '',
            'chrGenero' => '',
            'chrPracticasProf' => '',
            'chrServicioCom' => '',
            'chrTerapia' => '',
            'chrServicioSoc' => '',
            'chrFotoServSoc' => '',
            'chrHayCertLic' => '',
            'chrFotoCertLic' => '',
            'dtfIniServSoc' => '2023-01-01',
            'dtfFinServSoc' => '2023-01-01',
            'chrFolioServSoc' => '',
            'chrFechaImpCertLic' => '2023-01-01',
            'chrFolioCertLic' => '',
            'chrNotas' => '',
            'intConsecutivoPago' => '0',
            'chrHayAdeudoBiblio' => '',
            'chrHayAdeudoCom' => '',
            'chrFoto' => '',
            'cveCiclo' => '',
            'chrStatus' => $request->input('chrStatus'),

        ]);

        $usuario->save();


        return response()->json([ 'success' => true, 'message' => 'Usuario creado correctamente' ]);


    } catch (\Exception $e) {
        return response()->json([ 'success' => false, 'message' => $e->getMessage() ]);
    }
    }


    //Editar usuario

    public function edit($clave)
    {
        $usuarioedit = Usuario::find($clave);

        return response()->json($usuarioedit);


    }

    public function update(Request $request, $clave)
    {
        try {
            $this->table = 'tblusuario';

            // Valida los datos del formulario
            $request->validate([
                'chrClave' => 'required|string|max:8|unique:tblusuario,chrClave,' . $clave . ',intUsuario',
                'chrPassword' => 'required|string|min:6',
                'chrClavePlantel' => 'required',
                'chrNombre' => 'required|string|max:255',
                'chrPaterno' => 'required|string|max:255',
                'chrMaterno' => 'required|string|max:255',
                'dtFechaNacimiento' => 'nullable|date',
                'chrCurp' => 'required|string|max:18|unique:tblusuario,chrCurp,' . $clave . ',intUsuario|min:16',
                'chrEmail' => 'nullable|email',
                'chrTelefono' => 'nullable|string|max:255',
                'chrDomicilio' => 'nullable|string|max:255',
                'chrRFC' => 'nullable|string|max:13',

            ]);

            $usuarioedit = Usuario::find($id);
            $usuarioedit->chrClave = $request->input('chrClave');
            $usuarioedit->chrPassword = sha1($request->input('chrPassword_u') . "--_*Unimu01*_");
            $usuarioedit->chrClaveEscuela = $request->input('chrClavePlantel_u');
            $usuarioedit->chrNombre = $request->input('chrNombre_u');
            $usuarioedit->chrPaterno = $request->input('chrPaterno_u');
            $usuarioedit->chrMaterno = $request->input('chrMaterno_u');
            //si es null poner ''
            $usuarioedit->dtFechaNacimiento = $request->input('dtFechaNacimiento_u') == null ? '2023-01-01' : $request->input('dtFechaNacimiento_u');
            $usuarioedit->chrCurp = $request->input('chrCurp_u') == null ? '' : $request->input('chrCurp_u');
            $usuarioedit->chrEmail = $request->input('chrEmail_u') == null ? '' : $request->input('chrEmail_u');
            $usuarioedit->chrTelefono = $request->input('chrTelefono_u') == null ? '' : $request->input('chrTelefono_u');
            $usuarioedit->chrDomicilio = $request->input('chrDomicilio_u') == null ? '' : $request->input('chrDomicilio_u');
            $usuarioedit->chrRFC = $request->input('chrRFC') == null ? '' : $request->input('chrRFC');
            $usuarioedit->chrTipoUsuario = 'usuario';
            $usuarioedit->chrModalidad = '';
            $usuarioedit->chrHayActa = '';
            $usuarioedit->chrFotoActa = '';
            $usuarioedit->chrHayDomi = '';
            $usuarioedit->chrEnAccidente = '';
            $usuarioedit->chrEscuelaProcedencia = '';
            $usuarioedit->chrHayCertificado = '';
            $usuarioedit->chrFotoCertPrep = '';
            $usuarioedit->chrGenero = '';
            $usuarioedit->chrPracticasProf = '';
            $usuarioedit->chrServicioCom = '';
            $usuarioedit->chrTerapia = '';
            $usuarioedit->chrServicioSoc = '';
            $usuarioedit->chrFotoServSoc = '';
            $usuarioedit->chrHayCertLic = '';
            $usuarioedit->chrFotoCertLic = '';
            $usuarioedit->dtfIniServSoc = '2023-01-01';
            $usuarioedit->dtfFinServSoc = '2023-01-01';
            $usuarioedit->chrFolioServSoc = '';
            $usuarioedit->chrFechaImpCertLic = '2023-01-01';
            $usuarioedit->chrFolioCertLic = '';
            $usuarioedit->chrNotas = '';
            $usuarioedit->intConsecutivoPago = '0';
            $usuarioedit->chrHayAdeudoBiblio = '';
            $usuarioedit->chrHayAdeudoCom = '';
            $usuarioedit->chrFoto = '';
            $usuarioedit->cveCiclo = '';
            $usuarioedit->chrStatus = $request->input('chrStatus_u');

            $usuarioedit->save();

            return response()->json(['success' => true, 'message' => 'Usuario actualizado correctamente']);


        } catch (\Exception $e) {

            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }

    }}


